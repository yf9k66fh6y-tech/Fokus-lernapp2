# Fokus Lern-App

Eine browserbasierte Lern-App mit To-do-Funktionen, Heimsuchung-Textstellen-Trainer und Englischtrainer.

## Lokal testen
Öffne `index.html` in einem modernen Browser.

## Auf GitHub Pages veröffentlichen
1. Erstelle auf GitHub ein neues **Public** Repository, zum Beispiel `fokus-lernapp`.
2. Lade `index.html`, `.nojekyll` und `README.md` in das Stammverzeichnis des Repositories hoch.
3. Öffne **Settings → Pages**.
4. Wähle unter **Build and deployment** die Option **Deploy from a branch**.
5. Wähle Branch `main` und Ordner `/ (root)`, dann **Save**.
6. Warte, bis GitHub Pages die Website veröffentlicht hat. Die URL steht danach im Bereich **Settings → Pages**.

Hinweis: Die App ist eine statische Browser-App. Daten, die lokal gespeichert werden, sind standardmäßig nur im jeweiligen Browser vorhanden und werden nicht automatisch zwischen Freunden oder Geräten synchronisiert. Für serverseitige KI-Auswertung oder gemeinsame Konten wäre eine zusätzliche Backend-Anbindung nötig.
